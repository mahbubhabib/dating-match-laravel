<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Welcome to Dating App!</title>

    <style type="text/css">

        ::selection { background-color: #E13300; color: white; }
        ::-moz-selection { background-color: #E13300; color: white; }

        body {
            background: url("/date_app2/public/image/dating.jpg") no-repeat;
            margin: 40px;
            font: 13px/20px normal Helvetica, Arial, sans-serif;
            color: #4F5155;
        }


        h1 {
            color: #aa0000;
            background-color: transparent;

            font-size: 50px;
        }

        #container {
            border: 1px solid #D0D0D0;
            box-shadow: 0 0 8px #D0D0D0;
            text-align: center;
        }


        #log{
            width: 600px;
            box-shadow: 0px 0px 31px #888;
            margin-top: 150px;
            margin-bottom: 350px;
            border-radius: 3px;
            margin-left: 500px;

        }

        .error{
            color: crimson;
        }
        td{
            color:#ffffff;
        }


    </style>

</head>

</head>
<body>

<div id="container">
    <h1>Welcome to Dating App!(Laravel)</h1>

</div>

<div id="log" >
    <h2 style="background-color:#aa0000;color:#ffffff;padding: 13px;border-radius: 3px;" align="center">Login</h2>

    {!! Form::open(['route' => 'signin','method' =>'POST', 'class'=>'form-horizontal']) !!}
        <table align="center">

            <tr>
                <td>{!! Form::label('email', 'Email') !!}</td>
                <td>{!! Form::text('email', null, ['class' => 'form-control','placeholder' => 'example@example.com']) !!}</td>

            </tr>

            <tr>
                <td>{!! Form::label('password', 'Password') !!}</td>
                <td>{!! Form::text('password', null, ['class' => 'form-control','placeholder' => '******']) !!}</td>

            </tr>
            <td colspan="2"><button type="submit" name="btn" class="btn btn-success btn-block">Login</button></td>
        </table>


    {!! Form::close() !!}
    <br />


</div>


</body>
</html>