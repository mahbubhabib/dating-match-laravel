@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">User List</div>

                    <div class="card-body">
                        <div class="container">
                            <div class="row">

                                @forelse($users as $user)
                                    <div class="col-lg-4 col-md-6 mb-4">
                                        <div class="card h-100">
                                            <a href="#"><img class="card-img-top" src="/date_app/image/{{$user->image}}" alt=""></a>
                                            <div class="card-body">
                                                <h4 class="card-title">
                                                    <a href="#">Name: {{$user->name}}</a>
                                                </h4>
                                                <h6>Distance: {{$user->address}}</h6>
                                                <h5>Gender: {{($user->gender == 'male') ? 'Male' : 'Female'}}</h5>
                                                @php
                                                    $current_date = Carbon\Carbon::now('Asia/Bangkok');
                                                    $birthdate = Carbon\Carbon::createFromTimeStamp(strtotime($user->birthdate),'Asia/Bangkok');
                                                    $dob = $birthdate ->diff($current_date)->format('%Y yrs');
                                                @endphp
                                                <p>Age: {{$dob}}</p>
                                            </div>
                                            <div class="card-footer">

                                                    <a href="{{ route('match', $user->id) }}" class="btn btn-info btn-lg">
                                                        <span class="glyphicon glyphicon-thumbs-up"></span> Like
                                                    </a>
                                                    <a href="{{ route('unmatch', $user->id) }}" class="btn btn-danger btn-lg">
                                                        <span class="glyphicon glyphicon-thumbs-up"></span> DisLike
                                                    </a>

                                            </div>
                                        </div>
                                    </div>
                                @endforeach

                            </div>
                            <!-- /.row -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var msg = '{{Session::get('jsAlert')}}';
        var exist = '{{Session::has('jsAlert')}}';
        if(exist){
            alert(msg);
        }
    </script>
@endsection
