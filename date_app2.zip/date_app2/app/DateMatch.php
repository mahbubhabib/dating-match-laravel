<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DateMatch extends Model
{
    //
}
