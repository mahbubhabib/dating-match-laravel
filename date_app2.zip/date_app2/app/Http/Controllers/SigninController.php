<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use Session;

class SigninController extends Controller
{

    public function index()
    {
        return view('signin');
    }

    public function signin(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        if(Auth::attempt(['email'=>$email,'password' => $password])){
            session(['email'=>$email]);
            return redirect('/dashboard');
        }else{
            echo "Login Failed";
        }
    }

}
