<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">User List</div>

                    <div class="card-body">
                        <div class="container">
                            <div class="row">

                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-lg-4 col-md-6 mb-4">
                                        <div class="card h-100">
                                            <a href="#"><img class="card-img-top" src="/date_app/image/<?php echo e($user->image); ?>" alt=""></a>
                                            <div class="card-body">
                                                <h4 class="card-title">
                                                    <a href="#">Name: <?php echo e($user->name); ?></a>
                                                </h4>
                                                <h6>Distance: <?php echo e($user->address); ?></h6>
                                                <h5>Gender: <?php echo e(($user->gender == 'male') ? 'Male' : 'Female'); ?></h5>
                                                <?php
                                                    $current_date = Carbon\Carbon::now('Asia/Bangkok');
                                                    $birthdate = Carbon\Carbon::createFromTimeStamp(strtotime($user->birthdate),'Asia/Bangkok');
                                                    $dob = $birthdate ->diff($current_date)->format('%Y yrs');
                                                ?>
                                                <p>Age: <?php echo e($dob); ?></p>
                                            </div>
                                            <div class="card-footer">

                                                    <a href="<?php echo e(route('match', $user->id)); ?>" class="btn btn-info btn-lg">
                                                        <span class="glyphicon glyphicon-thumbs-up"></span> Like
                                                    </a>
                                                    <a href="<?php echo e(route('unmatch', $user->id)); ?>" class="btn btn-danger btn-lg">
                                                        <span class="glyphicon glyphicon-thumbs-up"></span> DisLike
                                                    </a>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <!-- /.row -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var msg = '<?php echo e(Session::get('jsAlert')); ?>';
        var exist = '<?php echo e(Session::has('jsAlert')); ?>';
        if(exist){
            alert(msg);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>