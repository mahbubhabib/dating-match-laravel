<?php

namespace App\Http\Controllers;

use App\DateMatch;
use Illuminate\Http\Request;
use Session;
use App\User;
use Auth;
use DB;

class DashboardController extends Controller
{

    public function index()
    {
        $user_id = Auth::id();
       $users = User::all()->except($user_id);

        //$users = DB::select('SELECT id,name,email,address,birthdate,gender,image,( ( 6371 * acos( cos( radians(90) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-23) ) + sin( radians(90) ) * sin( radians( latitude ) ) ) )/1000) AS distance FROM users HAVING distance < 25 ORDER BY distance LIMIT 0 , 20');


        return view('dashboard',compact('users','user_id'));
    }

    public function match($id)
    {
        $user_id = Auth::id();

        $existMatches = DateMatch::where('user_id' , $user_id)->where('match_id',$id)->get();
        $checkMatches = DateMatch::where('match_id' , $user_id)->where('user_id',$id)->get();


        if(count($existMatches) == 0){
            $match = new DateMatch;
            $match->user_id = $user_id;
            $match->match_id = $id;
            $match->save();
            if(count($checkMatches) > 0){
                return redirect('/dashboard')->with('jsAlert', 'Hurray! Its match');
            }else {
                return redirect('/dashboard');
            }
        }else{
            return redirect('/dashboard')->with('jsAlert', 'Already likes this person!!');
        }



    }

    public function unmatch($id)
    {
        $user_id = Auth::id();
        $unmatch_id = DateMatch::where('user_id' , $user_id)->where('match_id',$id)->first();
//        return $unmatch_id;
        $unmatch = DateMatch::findOrFail($unmatch_id->id);

        $unmatch->delete();

        return redirect('/dashboard');
    }

    public function signout()
    {
        Session::flush();
        Auth::logout();
        return redirect('/');
    }
}
